//=====================================================
// GET ENROLLED COURSES
//=====================================================

const enrolledCourses =
JSON.parse(localStorage.getItem("enrolledCourses")) || [];

const courseTable =
document.getElementById("courseTable");

const notificationContainer =
document.getElementById("notificationContainer");

const quickOverview =
document.getElementById("quickOverview");


//=====================================================
// UPDATE DASHBOARD STATISTICS
//=====================================================

document.getElementById("enrolledCount").innerHTML =
enrolledCourses.length;

document.getElementById("completedCount").innerHTML = "0";

document.getElementById("assignmentCount").innerHTML = "0";

document.getElementById("overallProgress").innerHTML = "0%";


//=====================================================
// DISPLAY MY COURSES
//=====================================================

if(enrolledCourses.length===0){

courseTable.innerHTML=`

<tr>

<td colspan="3"
style="
text-align:center;
padding:40px;
color:gray;
">

No courses enrolled yet.

</td>

</tr>

`;

}
else{

let html="";

enrolledCourses.forEach(course=>{

html+=`

<tr>

<td>${course.title}</td>

<td>Enrolled</td>

<td>0%</td>

</tr>

`;

});

courseTable.innerHTML=html;

}


//=====================================================
// RECENT NOTIFICATIONS
//=====================================================

if(enrolledCourses.length===0){

notificationContainer.innerHTML=`

<p
style="
text-align:center;
padding:30px;
color:gray;
">

No notifications available.

</p>

`;

}
else{

notificationContainer.innerHTML=`

<div
style="
padding:20px;
background:#EFF6FF;
border-left:5px solid #2563EB;
border-radius:8px;
margin-bottom:15px;
">

You have successfully enrolled in
<b>${enrolledCourses.length}</b>
course(s).

</div>

<div
style="
padding:20px;
background:#F0FDF4;
border-left:5px solid #16A34A;
border-radius:8px;
">

Continue your learning journey by
starting your enrolled courses.

</div>

`;

}


//=====================================================
// QUICK OVERVIEW
//=====================================================

quickOverview.innerHTML=`

<p>

<b>Total Courses :</b>
${enrolledCourses.length}

</p>

<br>

<p>

<b>Completed :</b>
0

</p>

<br>

<p>

<b>Assignments :</b>
0

</p>

<br>

<p>

<b>Progress :</b>
0%

</p>

`;