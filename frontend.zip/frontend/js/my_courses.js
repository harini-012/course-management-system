//=====================================================
// COURSE NAMES
//=====================================================




//=====================================================
// GET ENROLLED COURSES FROM LOCAL STORAGE
//=====================================================

const enrolledCourses=

JSON.parse(localStorage.getItem("enrolledCourses")) || [];

const container=document.getElementById("courseContainer");


//=====================================================
// DISPLAY ENROLLED COURSES
//=====================================================

if(enrolledCourses.length===0){

container.innerHTML=`

<div class="empty">

<h3>No Courses Enrolled Yet</h3>

<p>

Browse courses and enroll to start learning.

</p>

<a href="courses.html" class="browse">

Browse Courses

</a>

</div>

`;

document.getElementById("totalCourses").innerHTML="0";
document.getElementById("enrolledCount").innerHTML="0";
document.getElementById("progressCount").innerHTML="0";
document.getElementById("completedCount").innerHTML="0";
document.getElementById("certificateCount").innerHTML="0";

}

else{

let html="";

enrolledCourses.forEach(function(course){

html+=`

<div class="course-card">

<div class="course-header">

<h3>${course.title}</h3>

<div class="status">

Enrolled

</div>

</div>

<div class="course-info">

<div class="info-box">

<h4>Status</h4>

<p>Not Started</p>

</div>

<div class="info-box">

<h4>Progress</h4>

<p>0%</p>

</div>

<div class="info-box">

<h4>Videos</h4>

<p>Available</p>

</div>

<div class="info-box">

<h4>Materials</h4>

<p>Available</p>

</div>

</div>

<div class="progress-title">

Learning Progress

</div>

<div class="progress">

<div class="progress-fill"

style="width:0%;">

</div>

</div>

<div class="progress-text">

0% Completed

</div>

<div class="buttons">

<button
class="btn start"
onclick="startCourse('${course.title}')">

Start Course

</button>
<button
class="btn details"
onclick="viewCourse('${course.title}')">

View Details

</button>

</div>

</div>

`;

});

container.innerHTML=html;


//=====================================================
// UPDATE STATISTICS
//=====================================================

document.getElementById("totalCourses").innerHTML=

enrolledCourses.length;

document.getElementById("enrolledCount").innerHTML=

enrolledCourses.length;

document.getElementById("progressCount").innerHTML=

enrolledCourses.length;

document.getElementById("completedCount").innerHTML="0";

document.getElementById("certificateCount").innerHTML="0";

document.getElementById("overallProgress").style.width="0%";

document.getElementById("overallProgressText").innerHTML="0% Completed";

document.getElementById("lessonCount").innerHTML="0";

document.getElementById("videoCount").innerHTML="0";

document.getElementById("assignmentCount").innerHTML="0";

document.getElementById("quizCount").innerHTML="0";


//=====================================================
// RECENT ACTIVITY
//=====================================================

document.getElementById("activityContainer").innerHTML=`

<div class="course-card">

<div class="course-header">

<h3>Recent Activity</h3>

<div class="status">

Today

</div>

</div>

<p style="font-size:17px;line-height:30px;color:#555;">

You have enrolled in

<b>${enrolledCourses.length}</b>

course(s).

Click

<b>Start Course</b>

to begin learning.

</p>

</div>

`;

}
function viewCourse(title){

    const enrolledCourses =
    JSON.parse(localStorage.getItem("enrolledCourses")) || [];

    const selected =
    enrolledCourses.find(c => c.title === title);

    if(selected){

        localStorage.setItem(
            "selectedCourse",
            JSON.stringify(selected)
        );

        window.location.href =
        "course_details.html";

    }

}
function startCourse(title){

    const selected =
    enrolledCourses.find(c => c.title === title);

    if(selected){

        localStorage.setItem(
            "selectedCourse",
            JSON.stringify(selected)
        );

        window.location.href = "start_course.html";

    }

}