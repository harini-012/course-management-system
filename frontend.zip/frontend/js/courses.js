// ===============================
// Course Management Script
// ===============================

// Current selected course
let selectedCourse = null;

// Display course details
function showCourse(title, description, duration, instructor) {

    selectedCourse = {
        title,
        description,
        duration,
        instructor
    };

    // Hide course list
    document.getElementById("courseList").style.display = "none";

    // Show details section
    document.getElementById("courseDetails").style.display = "block";

    // Fill course details
    document.getElementById("title").textContent = title;
    document.getElementById("description").textContent = description;
    document.getElementById("duration").textContent = duration;
    document.getElementById("instructor").textContent = instructor;

    // Scroll to top
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


// Back to course list
function goBack() {

    document.getElementById("courseDetails").style.display = "none";
    document.getElementById("courseList").style.display = "block";

    selectedCourse = null;
}


// Search Courses
const searchInput = document.getElementById("searchCourse");

if (searchInput) {

    searchInput.addEventListener("keyup", function () {

        const value = this.value.toLowerCase();

        const cards = document.querySelectorAll(".card");

        cards.forEach(card => {

            const title =
                card.querySelector("h3").textContent.toLowerCase();

            if (title.includes(value)) {

                card.style.display = "block";

            } else {

                card.style.display = "none";

            }

        });

    });

}


// Save selected course
function saveSelectedCourse() {

    if (selectedCourse) {

        localStorage.setItem(
            "selectedCourse",
            JSON.stringify(selectedCourse)
        );

    }

}


// Open course details page
function openCoursePage() {

    saveSelectedCourse();

    window.location.href = "course_details.html";

}


// Enroll Course
function enrollCourse() {

    if (!selectedCourse) {

        alert("No course selected.");

        return;
    }

    let enrolled =
        JSON.parse(localStorage.getItem("enrolledCourses")) || [];

    const alreadyEnrolled =
        enrolled.some(course => course.title === selectedCourse.title);

    if (alreadyEnrolled) {

        alert("You are already enrolled in this course.");

        return;
    }

    enrolled.push(selectedCourse);

    localStorage.setItem(
        "enrolledCourses",
        JSON.stringify(enrolled)
    );

    alert("Course enrolled successfully!");

}


// Load Course Details
window.addEventListener("load", function () {

    const course =
        JSON.parse(localStorage.getItem("selectedCourse"));

    if (course &&
        document.getElementById("title")) {

        document.getElementById("title").textContent =
            course.title;

        document.getElementById("description").textContent =
            course.description;

        document.getElementById("duration").textContent =
            course.duration;

        document.getElementById("instructor").textContent =
            course.instructor;
    }

});